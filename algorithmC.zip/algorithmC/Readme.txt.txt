AUTORES:

AGUIRRE LARROSA STEFANNY BRIGGITTE 
FLORES SOL�RZANO JUAN JOS� 
SESME VERA CARLOS ANTHONY
VEAS CERVANTES TONY FREDDY


CLASE PRINCIPAL:

main.java


ARCHIVOS:

prueba20.txt		20 elementos
prueba250.txt		250 elementos
prueba1000.txt		1000 elementos
prueba1000v2.txt	1000 elementos
prueba2000.txt		2000 elementos
prueba5000.txt		5000 elementos

Observaci�n: No existe un archivo cargado en el programa por default, el usuario debe elegir uno.


DEPENDENCIAS: 

Tener instalada una versi�n actualizada de Netbeans.
Raz�n: A la integrante Aguirre le dio una alerta de error al ejecutar el programa, indic�ndole que deb�a actualizar la versi�n, por lo que tuvo que actualizar la versi�n de Netbeans.